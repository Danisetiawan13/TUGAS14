class Jobs {
  String jobPosition;
  String companyName;
  String location;
  String salaryRange;
  String logoName;
  bool savedJob;

  Jobs({
    this.jobPosition,
    this.companyName,
    this.location,
    this.salaryRange,
    this.logoName,
    this.savedJob
  });
}